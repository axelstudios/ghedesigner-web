import importlib.metadata

VERSION = importlib.metadata.version("SecondaryCoolantProps")
