#!/usr/bin/env python
from ghedesigner.gui.main_window import GHEDesignerWindow


def main_gui():
    GHEDesignerWindow().run()


if __name__ == "__main__":
    main_gui()
